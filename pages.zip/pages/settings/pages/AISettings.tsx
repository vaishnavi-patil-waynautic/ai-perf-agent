// export default function AISettings() {
//   return (
//     <div className="p-8 space-y-12 bg-gray-50 min-h-screen">

//       {/* Variation 1: Modern Glass Card */}
//       <div className="max-w-2xl">
//         <h2 className="text-sm text-gray-500 mb-4">Variation 1: Modern Glass Card</h2>
//         <div className="bg-white/70 backdrop-blur border border-gray-200 p-6 rounded-2xl shadow-lg space-y-4">
//           <h1 className="text-2xl font-bold text-gray-900">AI Settings</h1>
//           <select className="w-full p-2.5 rounded-lg border"> 
//             <option>GPT-4</option>
//             <option>GPT-3.5</option>
//           </select>
//           <input className="w-full p-2.5 rounded-lg border" placeholder="Rate Limit" />
//         </div>
//       </div>

//       {/* Variation 2: Gradient Border Card */}
//       <div className="max-w-2xl">
//         <h2 className="text-sm text-gray-500 mb-4">Variation 2: Gradient Border Card</h2>
//         <div className="relative rounded-xl overflow-hidden">
//           <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-blue-500 opacity-20" />
//           <div className="relative bg-white p-6 rounded-xl space-y-4">
//             <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
//               AI Settings
//             </h1>
//             <select className="w-full border p-2 rounded-md" />
//             <input className="w-full border p-2 rounded-md" placeholder="Rate Limit" />
//           </div>
//         </div>
//       </div>

//       {/* Variation 3: Minimal Shadow Card */}
//       <div className="max-w-2xl">
//         <h2 className="text-sm text-gray-500 mb-4">Variation 3: Minimal Shadow</h2>
//         <div className="bg-white p-6 rounded-lg border shadow-sm space-y-4">
//           <h1 className="text-xl font-semibold">AI Settings</h1>
//           <select className="w-full border p-2 rounded" />
//           <input className="w-full border p-2 rounded" placeholder="Rate Limit" />
//         </div>
//       </div>

//       {/* Variation 4: Bold Gradient Card */}
//       <div className="max-w-2xl">
//         <h2 className="text-sm text-gray-500 mb-4">Variation 4: Bold Gradient</h2>
//         <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-6 rounded-2xl text-white space-y-4">
//           <h1 className="text-2xl font-bold">AI Settings</h1>
//           <select className="w-full p-2 rounded text-gray-900" />
//           <input className="w-full p-2 rounded text-gray-900" placeholder="Rate Limit" />
//         </div>
//       </div>

//       {/* Variation 5: Outlined Minimalist */}
//       <div className="max-w-2xl">
//         <h2 className="text-sm text-gray-500 mb-4">Variation 5: Outlined</h2>
//         <div className="border-2 border-gray-300 p-6 rounded-lg bg-white space-y-4">
//           <h1 className="text-xl font-semibold">AI Settings</h1>
//           <select className="w-full border p-2 rounded" />
//           <input className="w-full border p-2 rounded" placeholder="Rate Limit" />
//         </div>
//       </div>

//       {/* Variation 6: Card with Icon */}
//       <div className="max-w-2xl">
//         <h2 className="text-sm text-gray-500 mb-4">Variation 6: With Icon</h2>
//         <div className="bg-white border p-6 rounded-xl shadow space-y-4">
//           <div className="flex items-center gap-3">
//             <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
//               🤖
//             </div>
//             <h1 className="text-xl font-semibold">AI Settings</h1>
//           </div>
//           <select className="w-full border p-2 rounded" />
//           <input className="w-full border p-2 rounded" placeholder="Rate Limit" />
//         </div>
//       </div>

//       {/* Variation 7: Dark Mode Card */}
//       <div className="max-w-2xl">
//         <h2 className="text-sm text-gray-400 mb-4">Variation 7: Dark Mode</h2>
//         <div className="bg-gray-800 border border-gray-700 p-6 rounded-xl text-white space-y-4">
//           <h1 className="text-2xl font-bold">AI Settings</h1>
//           <select className="w-full bg-gray-700 border border-gray-600 p-2 rounded" />
//           <input className="w-full bg-gray-700 border border-gray-600 p-2 rounded" placeholder="Rate Limit" />
//         </div>
//       </div>

//       {/* Variation 8: Soft Pastel */}
//       <div className="max-w-2xl">
//         <h2 className="text-sm text-gray-500 mb-4">Variation 8: Soft Pastel</h2>
//         <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-6 rounded-2xl border space-y-4">
//           <h1 className="text-xl font-bold">AI Settings</h1>
//           <select className="w-full p-2 rounded border" />
//           <input className="w-full p-2 rounded border" placeholder="Rate Limit" />
//         </div>
//       </div>

//       {/* Variation 9: Split Two-Tone */}
//       <div className="max-w-2xl">
//         <h2 className="text-sm text-gray-500 mb-4">Variation 9: Two-Tone</h2>
//         <div className="flex rounded-xl overflow-hidden shadow">
//           <div className="bg-blue-600 p-6 text-white w-1/3 font-bold">
//             AI
//           </div>
//           <div className="bg-white p-6 flex-1 space-y-3">
//             <select className="w-full border p-2 rounded" />
//             <input className="w-full border p-2 rounded" placeholder="Rate Limit" />
//           </div>
//         </div>
//       </div>

//       {/* Variation 10: Neumorphic */}
//       <div className="max-w-2xl">
//         <h2 className="text-sm text-gray-500 mb-4">Variation 10: Neumorphic</h2>
//         <div
//           className="bg-gray-100 p-8 rounded-3xl space-y-4"
//           style={{
//             boxShadow:
//               "20px 20px 60px #bebebe, -20px -20px 60px #ffffff",
//           }}
//         >
//           <h1 className="text-xl font-semibold text-gray-800">AI Settings</h1>
//           <input className="w-full p-3 rounded-xl" placeholder="Rate Limit" />
//           <select className="w-full p-3 rounded-xl" />
//         </div>
//       </div>

//     </div>
//   );
// }



import { Download, Trash2 } from "lucide-react";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { createModel, deleteModel, fetchModels } from "../store/aiModel.thunk";
import { AppDispatch, RootState } from "@/store/store";

export default function AISettings() {
  const dispatch = useDispatch<AppDispatch>();
  const [open, setOpen] = useState(false);
  const models = useSelector((state: RootState) => state.aiModel.models);
  const [form, setForm] = useState({
    name: "",
    api_token: "",
    rateLimit: "",
    provider: "",
  });

  const [showFormError, setShowFormError] = useState(false);

  useEffect(() => {
    dispatch(fetchModels());
  }, [dispatch]);

  const validateField = (name: string, value: string) => {
    if (!value) return "This field is required";

    if (name === "rateLimit") {
      const num = Number(value);
      if (isNaN(num)) return "Enter a valid number";
      if (num < 0) return "Value cannot be negative";
    }

    return "";
  };

  const isRateLimitInvalid =
  form.rateLimit !== "" && Number(form.rateLimit) < 0;

  const isFormValid =
  form.name &&
  form.provider &&
  form.api_token &&
  form.rateLimit &&
  !isRateLimitInvalid;

  const handleAdd = () => {
  if (!isFormValid) {
    setShowFormError(true);
    return;
  }
    dispatch(
      createModel({
        name: form.name,
        rate_limit: form.rateLimit,
        provider: form.provider,
        api_token: form.api_token
      })
    );

    setForm({ name: "", api_token: "", rateLimit: "", provider: "" });
    setOpen(false);
  };

  const handleDelete = (id) => {
    dispatch(deleteModel(id));
  };

  return (
    <div className="p-8 bg-gray-50 min-h-screen">

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold text-gray-800">AI Settings</h1>

        <button
          onClick={() => setOpen(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow-sm transition"
        >
          + Add Model
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-gray-600 px-5">
            <tr>
              <th className="text-left p-3 font-medium px-5">Model Name</th>
              <th className="text-left p-3 font-medium">Provider</th>
              <th className="text-left p-3 font-medium">Rate Limit</th>
              <th className="text-right p-3 font-medium px-5">Action</th>
            </tr>
          </thead>

          <tbody>
            {models.length === 0 && (
              <tr>
                <td colSpan={3} className="text-center p-6 text-gray-400">
                  No models added
                </td>
              </tr>
            )}

            {models.map((model) => (
              <tr
                key={model.id}
                className="border-t hover:bg-gray-50 transition px-5"
              >
                <td className="p-3 font-medium text-gray-800 px-5">
                  {model.name}
                </td>

                <td className="p-3 font-medium text-gray-800 px-5">
                  {model.provider}
                </td>

                <td className="p-3 text-gray-600">{model.rate_limit}</td>

                <td className="p-3 text-right px-8">
                  <button
                    onClick={() => handleDelete(model.id)}
                    className="text-red-500 hover:text-red-600 transition"
                  >
                    <Trash2 size={14} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {open && (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white w-full max-w-md rounded-xl shadow-lg p-6 space-y-4 animate-fadeIn">

            <h2 className="text-lg font-semibold text-gray-800">
              Add AI Model
            </h2>

            <input
  placeholder="Model Name"
  value={form.name}
  maxLength={50}
  onChange={(e) =>
    setForm({ ...form, name: e.target.value })
  }
  className={`w-full border rounded-lg p-2.5 outline-none focus:ring-2 focus:ring-blue-500"
  }`}
/>
{form.name.length >= 50 && (
  <p className="text-red-500 text-xs mt-1">Model name cannot exceed 50 characters</p>
)}

            <input
              placeholder="Provider"
              value={form.provider}
              maxLength={50}
              onChange={(e) =>
                setForm({ ...form, provider: e.target.value })
              }
              className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
            />
            {form.provider.length >= 50 && (
              <p className="text-red-500 text-xs mt-1">Provider cannot exceed 50 characters</p>
            )}

            
            <input
              placeholder="API Token"
              value={form.api_token}
              type="password"
              onChange={(e) =>
                setForm({ ...form, api_token: e.target.value })
              }
              className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
            />

            
            <input
  placeholder="Rate Limit"
  type="number"
  value={form.rateLimit}
  onChange={(e) =>
    setForm({ ...form, rateLimit: e.target.value })
  }
  className={`w-full border rounded-lg p-2.5 outline-none ${
    isRateLimitInvalid
      ? "border-red-500"
      : "focus:ring-2 focus:ring-blue-500"
  }`}
/>

{isRateLimitInvalid && (
  <p className="text-red-500 text-xs">
    Value cannot be negative
  </p>
)}

{showFormError && (
  <p className="text-red-500 text-sm">
    Please fill all required fields correctly
  </p>
)}

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setOpen(false)}
                className="px-4 py-2 rounded-lg border text-gray-600 hover:bg-gray-50"
              >
                Cancel
              </button>

              <button
  onClick={handleAdd}
  disabled={!isFormValid}
  title={!isFormValid ? "Please Fill all fields correctly !" : "Add Model"}
  className={`px-4 py-2 rounded-lg shadow-sm text-white ${
    isFormValid
      ? "bg-blue-600 hover:bg-blue-700"
      : "bg-gray-400 cursor-not-allowed"
  }`}
>
  Add
</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
