// import { Box } from '@mui/material';
// import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

// export const BarChartWidget = ({ data }: any) => {
//   return (
//     <Box sx={{ height: 250, width: '100%' }}>
//       <ResponsiveContainer>
//         <BarChart data={data} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
//           <XAxis dataKey="build" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
//           <YAxis hide />
//           <Tooltip cursor={{ fill: '#f5f5f5' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
//           <Bar dataKey="compliance" radius={[4, 4, 0, 0]}>
//             {data.map((entry: any, index: number) => (
//               <Cell key={`cell-${index}`} fill={entry.compliance > 90 ? '#4caf50' : '#1976d2'} />
//             ))}
//           </Bar>
//         </BarChart>
//       </ResponsiveContainer>
//     </Box>
//   );
// };

import { Box } from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

export const BarChartWidget = ({ data }: any) => {
  // Custom tooltip
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <Box
          sx={{
            background: 'rgba(15, 23, 42, 0.95)',
            backdropFilter: 'blur(12px)',
            borderRadius: '12px',
            padding: '12px 16px',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)',
          }}
        >
          <Box sx={{ color: '#fff', fontSize: '0.75rem', fontWeight: 600, mb: 0.5 }}>
            {payload[0].payload.build}
          </Box>
          <Box sx={{ color: '#94a3b8', fontSize: '0.7rem' }}>
            Compliance: <span style={{ color: '#3b82f6', fontWeight: 700 }}>{payload[0].value}%</span>
          </Box>
        </Box>
      );
    }
    return null;
  };

  return (
    <Box sx={{ height: 280, width: '100%', px: 1, py: 2 }}>
      <ResponsiveContainer>
        <BarChart 
          data={data} 
          margin={{ top: 10, right: 20, left: -10, bottom: 20 }}
        >
          <defs>
            <linearGradient id="barGradientHigh" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#22c55e" stopOpacity={0.9}/>
              <stop offset="100%" stopColor="#16a34a" stopOpacity={1}/>
            </linearGradient>
            <linearGradient id="barGradientNormal" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.9}/>
              <stop offset="100%" stopColor="#2563eb" stopOpacity={1}/>
            </linearGradient>
          </defs>
          
          <XAxis 
            dataKey="build" 
            tick={{ fontSize: 11, fill: '#64748b', fontWeight: 500 }}
            axisLine={false}
            tickLine={false}
            dy={10}
          />
          
          <YAxis 
            tick={{ fontSize: 11, fill: '#64748b' }}
            axisLine={false}
            tickLine={false}
            dx={-5}
          />
          
          <Tooltip 
            content={<CustomTooltip />}
            cursor={{ fill: 'rgba(148, 163, 184, 0.1)', radius: 8 }}
          />
          
          <Bar 
            dataKey="compliance" 
            radius={[8, 8, 0, 0]}
            maxBarSize={60}
          >
            {data.map((entry: any, index: number) => (
              <Cell 
                key={`cell-${index}`} 
                fill={entry.compliance > 90 ? 'url(#barGradientHigh)' : 'url(#barGradientNormal)'}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </Box>
  );
};