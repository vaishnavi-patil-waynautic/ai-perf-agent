// import React, { useState } from 'react';
// import { Box, Skeleton, IconButton, Tooltip, Accordion, AccordionSummary, AccordionDetails, Typography, Divider } from '@mui/material';
// import { Edit, Save } from '@mui/icons-material';
// import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
// import { useQuery } from '@tanstack/react-query';
// import { renderWidget } from '../components/dashboard/WidgetRegistry';
// import { useSelector } from 'react-redux';
// import { WidgetConfig } from '../types/widget';
// import { WidgetBoundary } from '../components/dashboard/WidgetBoundary';
// import { mockWidgets } from '../data/mockDashboard';

// const dashboardSections = [
//   {
//     title: '📊 Executive Overview',
//     description: 'Quick snapshot of performance, reliability, and testing maturity.',
//     widgetIds: ['kpi-1', 'kpi-2', 'kpi-3', 'kpi-4'],
//   },
//   {
//     title: '📈 Performance Trends',
//     description: 'Response time and throughput trends over time.',
//     widgetIds: ['line-1'],
//   },
//   {
//     title: '📋 Recent Activity',
//     description: 'Latest JMX scripts and test runs.',
//     widgetIds: ['table-1'],
//   },
// ];

// const GovernanceDashboard: React.FC = () => {
//   const [isEditMode, setIsEditMode] = useState(false);
//   const filters = useSelector((state: any) => state.dashboard?.filters ?? {});

//   const { data: dashboard, isLoading } = useQuery({
//     queryKey: ['dashboard', 'governance-main'],
//     queryFn: async () => ({ widgets: mockWidgets }),
//   });

//   if (isLoading) return <Skeleton variant="rectangular" height="80vh" />;
//   if (!dashboard) return null;

//   return (
//     <Box sx={{ p: 3 }}>
//       <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//         <Typography variant="h5" fontWeight={700}>Governance Dashboard</Typography>
//         <Tooltip title={isEditMode ? 'Save Layout' : 'Edit Layout'}>
//           <IconButton onClick={() => setIsEditMode(!isEditMode)} color={isEditMode ? 'primary' : 'default'}>
//             {isEditMode ? <Save /> : <Edit />}
//           </IconButton>
//         </Tooltip>
//       </Box>

//       {dashboardSections.map((section, index) => {
//         const widgets = dashboard.widgets.filter((w: WidgetConfig) =>
//           section.widgetIds.includes(w.id)
//         );

//         return (
//           <Accordion key={index} defaultExpanded sx={{ mb: 2, borderRadius: 2, '&:before': { display: 'none' } }}>
//             <AccordionSummary expandIcon={<ExpandMoreIcon />}>
//               <Box>
//                 <Typography variant="h6" fontWeight={600}>{section.title}</Typography>
//                 <Typography variant="body2" color="text.secondary">{section.description}</Typography>
//               </Box>
//             </AccordionSummary>
//             <AccordionDetails>
//               <Divider sx={{ mb: 2 }} />
//               <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: 2 }}>
//                 {widgets.map((widget: WidgetConfig) => (
//                   <Box
//                     key={widget.id}
//                     sx={{
//                       gridColumn: `span ${widget.layout?.w ?? 4}`,
//                       minHeight: (widget.layout?.h ?? 2) * 100,
//                     }}
//                   >
//                     <WidgetBoundary title={widget.title}>
//                       {renderWidget(widget, filters)}
//                     </WidgetBoundary>
//                   </Box>
//                 ))}
//               </Box>
//             </AccordionDetails>
//           </Accordion>
//         );
//       })}
//     </Box>
//   );
// };

// export default GovernanceDashboard;

// version 2
// import React, { useState } from 'react';
// import {
//   Box,
//   Skeleton,
//   IconButton,
//   Tooltip,
//   Accordion,
//   AccordionSummary,
//   AccordionDetails,
//   Typography,
//   Divider
// } from '@mui/material';
// import { Edit, Save } from '@mui/icons-material';
// import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
// import { useQuery } from '@tanstack/react-query';
// import { renderWidget } from '../components/dashboard/WidgetRegistry';
// import { useSelector } from 'react-redux';
// import { WidgetConfig } from '../types/widget';
// import { WidgetBoundary } from '../components/dashboard/WidgetBoundary';
// import { mockWidgets } from '../data/mockDashboard';

// const dashboardSections = [
//   {
//     title: '📊 Executive Overview Dashboard',
//     description: 'Provides a quick snapshot of performance and reliability.',
//     widgetIds: [
//       'exec-kpi-1',
//       'exec-kpi-2',
//       'exec-kpi-3',
//       'exec-kpi-4',
//       'exec-kpi-5',
//       'exec-kpi-6',
//       'exec-line-1',
//     ],
//   },
//   {
//     title: '🚀 Autoscript Module Insights',
//     description: 'Tracks automation efficiency in generating JMeter scripts.',
//     widgetIds: [
//       'autoscript-kpi-1',
//       'autoscript-kpi-2',
//       'autoscript-kpi-3',
//       'autoscript-kpi-4',
//     ],
//   },
//   {
//     title: '📄 AutoNFR Insights',
//     description: 'Measures the effectiveness of automated NFR generation.',
//     widgetIds: ['autonfr-kpi-1', 'autonfr-kpi-2'],
//   },
//   {
//     title: '🔗 AutoAnalysis Integrations Dashboard',
//     description: 'Provides visibility into integrated tools and automated builds.',
//     widgetIds: ['autoanalysis-bar'],
//   },
//   {
//     title: '📈 ROI & Productivity Dashboard',
//     description: 'Demonstrates the measurable impact of your platform.',
//     widgetIds: ['roi-kpi-1', 'roi-kpi-2', 'roi-kpi-3'],
//   },
// ];

// const GovernanceDashboard: React.FC = () => {
//   const [isEditMode, setIsEditMode] = useState(false);
//   const filters = useSelector((state: any) => state.dashboard?.filters ?? {});

//   const { data, isLoading } = useQuery({
//     queryKey: ['dashboard', 'governance-main'],
//     queryFn: async () => ({ widgets: mockWidgets }),
//     initialData: { widgets: mockWidgets }, // Ensures correct structure
//   });

//   // ✅ Normalize widgets to always be an array
//   const widgets: WidgetConfig[] = Array.isArray(data?.widgets)
//     ? data.widgets
//     : [];

//   if (isLoading) {
//     return <Skeleton variant="rectangular" height="80vh" />;
//   }

//   return (
//     <Box sx={{ p: 3 }}>
//       {/* Header */}
//       <Box
//         sx={{
//           mb: 2,
//           display: 'flex',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//         }}
//       >
//         <Typography variant="h5" fontWeight={700}>
//           Governance Dashboard
//         </Typography>

//         <Tooltip title={isEditMode ? 'Save Layout' : 'Edit Layout'}>
//           <IconButton
//             onClick={() => setIsEditMode(!isEditMode)}
//             color={isEditMode ? 'primary' : 'default'}
//           >
//             {isEditMode ? <Save /> : <Edit />}
//           </IconButton>
//         </Tooltip>
//       </Box>

//       {/* Empty State */}
//       {widgets.length === 0 ? (
//         <Box sx={{ textAlign: 'center', py: 10, color: 'text.secondary' }}>
//           <Typography variant="h6">No widgets configured.</Typography>
//           <Typography variant="body2">
//             Connect your backend to load dashboard data.
//           </Typography>
//         </Box>
//       ) : (
//         dashboardSections.map((section, index) => {
//           const sectionWidgets = widgets.filter((w: WidgetConfig) =>
//             section.widgetIds.includes(w.id)
//           );

//           if (sectionWidgets.length === 0) return null;

//           return (
//             <Accordion
//               key={index}
//               defaultExpanded
//               sx={{
//                 mb: 2,
//                 borderRadius: 2,
//                 border: '1px solid #e0e0e0',
//                 boxShadow: 'none',
//                 '&:before': { display: 'none' },
//               }}
//             >
//               <AccordionSummary expandIcon={<ExpandMoreIcon />}>
//                 <Box>
//                   <Typography variant="h6" fontWeight={600}>
//                     {section.title}
//                   </Typography>
//                   <Typography variant="body2" color="text.secondary">
//                     {section.description}
//                   </Typography>
//                 </Box>
//               </AccordionSummary>

//               <AccordionDetails>
//                 <Divider sx={{ mb: 2 }} />
//                 <Box
//                   sx={{
//                     display: 'grid',
//                     gridTemplateColumns: 'repeat(12, 1fr)',
//                     gap: 2,
//                   }}
//                 >
//                   {sectionWidgets.map((widget: WidgetConfig) => (
//                     <Box
//                       key={widget.id}
//                       sx={{
//                         gridColumn: `span ${widget.layout?.w ?? 4}`,
//                         minHeight: (widget.layout?.h ?? 2) * 100,
//                       }}
//                     >
//                       <WidgetBoundary title={widget.title}>
//                         {renderWidget(widget, filters)}
//                       </WidgetBoundary>
//                     </Box>
//                   ))}
//                 </Box>
//               </AccordionDetails>
//             </Accordion>
//           );
//         })
//       )}
//     </Box>
//   );
// };

// export default GovernanceDashboard;



import React, { useState } from 'react';
import {
  Box,
  Skeleton,
  IconButton,
  Tooltip,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Divider,
  Container
} from '@mui/material';
import { Edit, Save, ExpandMore } from '@mui/icons-material';
import { useQuery } from '@tanstack/react-query';
import { renderWidget } from '../components/dashboard/WidgetRegistry';
import { useSelector } from 'react-redux';
import { WidgetConfig } from '../types/widget';
import { WidgetBoundary } from '../components/dashboard/WidgetBoundary';
import { mockWidgets } from '../data/mockDashboard';

const dashboardSections = [
  {
    title: '📊 Executive Overview',
    description: 'Real-time snapshot of performance and reliability metrics',
    icon: '📊',
    widgetIds: [
      'exec-kpi-1',
      'exec-kpi-2',
      'exec-kpi-3',
      'exec-kpi-4',
      'exec-kpi-5',
      'exec-kpi-6',
      'exec-line-1',
    ],
  },
  {
    title: '🚀 Autoscript Module',
    description: 'Automation efficiency and script generation analytics',
    icon: '🚀',
    widgetIds: [
      'autoscript-kpi-1',
      'autoscript-kpi-2',
      'autoscript-kpi-3',
      'autoscript-kpi-4',
    ],
  },
  {
    title: '📄 AutoNFR Insights',
    description: 'Automated NFR generation effectiveness metrics',
    icon: '📄',
    widgetIds: ['autonfr-kpi-1', 'autonfr-kpi-2'],
  },
  {
    title: '🔗 AutoAnalysis Integrations',
    description: 'Integrated tools and automated build visibility',
    icon: '🔗',
    widgetIds: ['autoanalysis-bar'],
  },
  {
    title: '📈 ROI & Productivity',
    description: 'Measurable platform impact and value metrics',
    icon: '📈',
    widgetIds: ['roi-kpi-1', 'roi-kpi-2', 'roi-kpi-3'],
  },
];

const GovernanceDashboard: React.FC = () => {
  const [isEditMode, setIsEditMode] = useState(false);
  const filters = useSelector((state: any) => state.dashboard?.filters ?? {});

  const { data, isLoading } = useQuery({
    queryKey: ['dashboard', 'governance-main'],
    queryFn: async () => ({ widgets: mockWidgets }),
    initialData: { widgets: mockWidgets },
  });

  const widgets: WidgetConfig[] = Array.isArray(data?.widgets) ? data.widgets : [];

  if (isLoading) {
    return (
      <Box sx={{ minHeight: '100vh', background: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)' }}>
        <Container maxWidth="xl" sx={{ pt: 4, pb: 6 }}>
          <Skeleton 
            variant="rectangular" 
            height="80vh" 
            sx={{ borderRadius: '24px', bgcolor: 'rgba(255,255,255,0.6)' }}
          />
        </Container>
      </Box>
    );
  }

  return (
    <Box 
      sx={{ 
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)',
        px: 20,
        py:6
      }}
    >
      <Container maxWidth="xl">
        {/* Header */}
        <Box
          sx={{
            pt: 4,
            pb: 3,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            position: 'sticky',
            top: 0,
            zIndex: 10,
            backgroundColor: 'rgba(248, 250, 252, 0.8)',
            backdropFilter: 'blur(12px)',
            mx: -3,
            px: 3,
            mb: 2,
          }}
        >
          <Box>
            <Typography 
              variant="h4" 
              sx={{ 
                fontWeight: 800,
                background: 'linear-gradient(135deg, #0f172a 0%, #334155 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                letterSpacing: '-0.02em',
                mb: 0.5
              }}
            >
              Governance Dashboard
            </Typography>
            <Typography 
              variant="body2" 
              sx={{ 
                color: '#64748b',
                fontWeight: 500
              }}
            >
              Monitor and analyze platform performance in real-time
            </Typography>
          </Box>

          <Tooltip title={isEditMode ? 'Save Layout' : 'Customize Dashboard'} arrow>
            <IconButton
              onClick={() => setIsEditMode(!isEditMode)}
              sx={{
                backgroundColor: isEditMode ? '#3b82f6' : 'rgba(255, 255, 255, 0.9)',
                color: isEditMode ? '#fff' : '#64748b',
                border: isEditMode ? 'none' : '1px solid rgba(226, 232, 240, 0.8)',
                borderRadius: '12px',
                width: 48,
                height: 48,
                boxShadow: isEditMode 
                  ? '0 4px 16px rgba(59, 130, 246, 0.3)'
                  : '0 2px 8px rgba(0, 0, 0, 0.05)',
                transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                '&:hover': {
                  backgroundColor: isEditMode ? '#2563eb' : 'rgba(255, 255, 255, 1)',
                  transform: 'translateY(-2px)',
                  boxShadow: isEditMode
                    ? '0 8px 24px rgba(59, 130, 246, 0.4)'
                    : '0 4px 16px rgba(0, 0, 0, 0.1)',
                },
              }}
            >
              {isEditMode ? <Save sx={{ fontSize: 20 }} /> : <Edit sx={{ fontSize: 20 }} />}
            </IconButton>
          </Tooltip>
        </Box>

        {/* Empty State */}
        {widgets.length === 0 ? (
          <Box 
            sx={{ 
              textAlign: 'center', 
              py: 12,
              px: 4,
              backgroundColor: 'rgba(255, 255, 255, 0.7)',
              borderRadius: '24px',
              border: '1px solid rgba(226, 232, 240, 0.8)',
            }}
          >
            <Typography 
              variant="h5" 
              sx={{ 
                color: '#334155',
                fontWeight: 700,
                mb: 1
              }}
            >
              No Widgets Configured
            </Typography>
            <Typography 
              variant="body1" 
              sx={{ 
                color: '#64748b',
                maxWidth: 400,
                mx: 'auto'
              }}
            >
              Connect your backend services to start visualizing your dashboard data
            </Typography>
          </Box>
        ) : (
          dashboardSections.map((section, index) => {
            const sectionWidgets = widgets.filter((w: WidgetConfig) =>
              section.widgetIds.includes(w.id)
            );

            if (sectionWidgets.length === 0) return null;

            return (
              <Accordion
                key={index}
                defaultExpanded
                sx={{
                  mb: 2.5,
                  borderRadius: '20px !important',
                  overflow: 'hidden',
                  backgroundColor: 'rgba(255, 255, 255, 0.7)',
                  backdropFilter: 'blur(20px)',
                  border: '1px solid rgba(226, 232, 240, 0.8)',
                  boxShadow: '0 4px 24px rgba(0, 0, 0, 0.06)',
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                  '&:before': { display: 'none' },
                  '&:hover': {
                    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08)',
                  },
                  '&.Mui-expanded': {
                    margin: '0 0 20px 0',
                  }
                }}
              >
                <AccordionSummary
                  expandIcon={
                    <ExpandMore 
                      sx={{ 
                        color: '#64748b',
                        fontSize: 28,
                        transition: 'transform 0.3s ease'
                      }} 
                    />
                  }
                  sx={{
                    px: 3,
                    py: 2,
                    minHeight: '80px !important',
                    '&.Mui-expanded': {
                      minHeight: '80px !important',
                    },
                    '& .MuiAccordionSummary-content': {
                      my: 1.5,
                    }
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
                    {/* <Box
                      sx={{
                        width: 48,
                        height: 48,
                        borderRadius: '14px',
                        background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '24px',
                        boxShadow: '0 4px 16px rgba(59, 130, 246, 0.3)',
                      }}
                    >
                      {section.icon}
                    </Box> */}
                    
                    <Box sx={{ flex: 1 }}>
                      <Typography 
                        variant="h6" 
                        sx={{ 
                          fontWeight: 700,
                          color: '#0f172a',
                          letterSpacing: '-0.01em',
                          mb: 0.5
                        }}
                      >
                        {section.title.replace(/^[^\s]+\s/, '')}
                      </Typography>
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          color: '#64748b',
                          fontWeight: 500,
                          fontSize: '0.875rem'
                        }}
                      >
                        {section.description}
                      </Typography>
                    </Box>

                    <Box
                      sx={{
                        px: 2,
                        py: 0.75,
                        borderRadius: '8px',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        border: '1px solid rgba(59, 130, 246, 0.2)',
                      }}
                    >
                      <Typography
                        sx={{
                          color: '#2563eb',
                          fontSize: '0.75rem',
                          fontWeight: 700,
                        }}
                      >
                        {sectionWidgets.length} Widget{sectionWidgets.length !== 1 ? 's' : ''}
                      </Typography>
                    </Box>
                  </Box>
                </AccordionSummary>

                <AccordionDetails sx={{ px: 3, pb: 3, pt: 1 }}>
                  <Box
                    sx={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(12, 1fr)',
                      gap: 2.5,
                    }}
                  >
                    {sectionWidgets.map((widget: WidgetConfig) => (
                      <Box
                        key={widget.id}
                        sx={{
                          gridColumn: `span ${widget.layout?.w ?? 4}`,
                          minHeight: (widget.layout?.h ?? 2) * 100,
                        }}
                      >
                        <WidgetBoundary title={widget.title}>
                          {renderWidget(widget, filters)}
                        </WidgetBoundary>
                      </Box>
                    ))}
                  </Box>
                </AccordionDetails>
              </Accordion>
            );
          })
        )}
      </Container>
    </Box>
  );
};

export default GovernanceDashboard;