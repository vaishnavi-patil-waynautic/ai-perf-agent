// import { WidgetConfig } from '../types/widget';

// // ── Mock widget configs ────────────────────────────────────────────────────
// export const mockWidgets: WidgetConfig[] = [
//   {
//     id: 'kpi-1',
//     type: 'KPI',
//     title: 'Avg Response Time',
//     dataSource: { url: '/metrics/response-time', method: 'GET' },
//     layout: { x: 0, y: 0, w: 3, h: 2 },
//     visuals: { color: '#1976d2' },
//   },
//   {
//     id: 'kpi-2',
//     type: 'KPI',
//     title: 'Error Rate',
//     dataSource: { url: '/metrics/error-rate', method: 'GET' },
//     layout: { x: 3, y: 0, w: 3, h: 2 },
//     visuals: { color: '#ef5350' },
//   },
//   {
//     id: 'kpi-3',
//     type: 'KPI',
//     title: 'Throughput (TPS)',
//     dataSource: { url: '/metrics/throughput', method: 'GET' },
//     layout: { x: 6, y: 0, w: 3, h: 2 },
//     visuals: { color: '#4caf50' },
//   },
//   {
//     id: 'kpi-4',
//     type: 'KPI',
//     title: 'NFR Compliance',
//     dataSource: { url: '/metrics/compliance', method: 'GET' },
//     layout: { x: 9, y: 0, w: 3, h: 2 },
//     visuals: { color: '#ff9800' },
//   },
//   {
//     id: 'line-1',
//     type: 'CHART_LINE',
//     title: 'Response Time Trend (7 days)',
//     dataSource: { url: '/metrics/response-trend', method: 'GET' },
//     layout: { x: 0, y: 2, w: 8, h: 3 },
//     visuals: { showLegend: true },
//   },
//   {
//     id: 'table-1',
//     type: 'TABLE',
//     title: 'Recent JMX Scripts',
//     dataSource: { url: '/scripts/recent', method: 'GET' },
//     layout: { x: 8, y: 2, w: 4, h: 3 },
//     visuals: {},
//   },
// ];

// // ── Mock data per widget id ────────────────────────────────────────────────
// export const mockWidgetData: Record<string, any> = {
//   'kpi-1': { value: '342 ms', trend: -8 },
//   'kpi-2': { value: '0.4%', trend: -2 },
//   'kpi-3': { value: '1,240', trend: 12 },
//   'kpi-4': { value: '94%', trend: 3 },
//   'line-1': [
//     { name: 'Mon', value: 380 },
//     { name: 'Tue', value: 420 },
//     { name: 'Wed', value: 310 },
//     { name: 'Thu', value: 290 },
//     { name: 'Fri', value: 342 },
//     { name: 'Sat', value: 260 },
//     { name: 'Sun', value: 300 },
//   ],
//   'table-1': [
//     { id: '1', name: 'checkout_flow_v3.jmx', status: 'success', timestamp: '2026-04-14 09:12' },
//     { id: '2', name: 'login_stress_v2.jmx', status: 'success', timestamp: '2026-04-13 15:44' },
//     { id: '3', name: 'api_load_test.jmx', status: 'failed', timestamp: '2026-04-13 11:20' },
//     { id: '4', name: 'catalog_browse.jmx', status: 'success', timestamp: '2026-04-12 08:55' },
//     { id: '5', name: 'payment_gateway.jmx', status: 'success', timestamp: '2026-04-11 17:30' },
//   ],
// };


// import { WidgetConfig } from '../types/widget';

// /* -------------------------------------------------------------------------- */
// /*                            Widget Configurations                           */
// /* -------------------------------------------------------------------------- */
// export const mockWidgets: WidgetConfig[] = [
//   // 📊 Executive Overview
//   {
//     id: 'exec-kpi-1',
//     type: 'KPI',
//     title: 'Total Applications Onboarded',
//     layout: { x: 0, y: 0, w: 2, h: 2 },
//     visuals: { color: '#1976d2' },
//   },
//   {
//     id: 'exec-kpi-2',
//     type: 'KPI',
//     title: 'Total Performance Tests Executed',
//     layout: { x: 2, y: 0, w: 2, h: 2 },
//     visuals: { color: '#2e7d32' },
//   },
//   {
//     id: 'exec-kpi-3',
//     type: 'KPI',
//     title: 'Success Rate',
//     layout: { x: 4, y: 0, w: 2, h: 2 },
//     visuals: { color: '#ed6c02' },
//   },
//   {
//     id: 'exec-kpi-4',
//     type: 'KPI',
//     title: 'Average Response Time',
//     layout: { x: 6, y: 0, w: 2, h: 2 },
//     visuals: { color: '#9c27b0' },
//   },
//   {
//     id: 'exec-kpi-5',
//     type: 'KPI',
//     title: 'Peak Throughput',
//     layout: { x: 8, y: 0, w: 2, h: 2 },
//     visuals: { color: '#0288d1' },
//   },
//   {
//     id: 'exec-kpi-6',
//     type: 'KPI',
//     title: 'Active Builds',
//     layout: { x: 10, y: 0, w: 2, h: 2 },
//     visuals: { color: '#d32f2f' },
//   },
//   {
//     id: 'exec-line-1',
//     type: 'CHART_LINE',
//     title: 'Performance Trends',
//     layout: { x: 0, y: 2, w: 12, h: 3 },
//     visuals: {},
//   },

//   // 🚀 Autoscript Insights
//   {
//     id: 'autoscript-kpi-1',
//     type: 'KPI',
//     title: 'HAR Files Processed',
//     layout: { x: 0, y: 0, w: 3, h: 2 },
//     visuals: { color: '#1976d2' },
//   },
//   {
//     id: 'autoscript-kpi-2',
//     type: 'KPI',
//     title: 'JMX Files Generated',
//     layout: { x: 3, y: 0, w: 3, h: 2 },
//     visuals: { color: '#2e7d32' },
//   },
//   {
//     id: 'autoscript-kpi-3',
//     type: 'KPI',
//     title: 'Script Success Rate',
//     layout: { x: 6, y: 0, w: 3, h: 2 },
//     visuals: { color: '#ed6c02' },
//   },
//   {
//     id: 'autoscript-kpi-4',
//     type: 'KPI',
//     title: 'Avg Script Generation Time',
//     layout: { x: 9, y: 0, w: 3, h: 2 },
//     visuals: { color: '#9c27b0' },
//   },

//   // 📄 AutoNFR Insights
//   {
//     id: 'autonfr-kpi-1',
//     type: 'KPI',
//     title: 'NFR Documents Generated',
//     layout: { x: 0, y: 0, w: 3, h: 2 },
//     visuals: { color: '#0288d1' },
//   },
//   {
//     id: 'autonfr-kpi-2',
//     type: 'KPI',
//     title: 'Compliance Coverage',
//     layout: { x: 3, y: 0, w: 3, h: 2 },
//     visuals: { color: '#ff9800' },
//   },

//   // 🔗 AutoAnalysis Dashboard
//   {
//     id: 'autoanalysis-bar',
//     type: 'CHART_BAR',
//     title: 'Build Success Rate',
//     layout: { x: 0, y: 0, w: 6, h: 3 },
//     visuals: {},
//   },

//   // 📈 ROI Dashboard
//   {
//     id: 'roi-kpi-1',
//     type: 'KPI',
//     title: 'Total Time Saved',
//     layout: { x: 0, y: 0, w: 3, h: 2 },
//     visuals: { color: '#4caf50' },
//   },
//   {
//     id: 'roi-kpi-2',
//     type: 'KPI',
//     title: 'Cost Savings',
//     layout: { x: 3, y: 0, w: 3, h: 2 },
//     visuals: { color: '#00acc1' },
//   },
//   {
//     id: 'roi-kpi-3',
//     type: 'KPI',
//     title: 'Return on Investment',
//     layout: { x: 6, y: 0, w: 3, h: 2 },
//     visuals: { color: '#8e24aa' },
//   },
// ];

// /* -------------------------------------------------------------------------- */
// /*                                Widget Data                                 */
// /* -------------------------------------------------------------------------- */
// export const mockWidgetData: Record<string, any> = {
//   'exec-kpi-1': { value: '128', trend: 12 },
//   'exec-kpi-2': { value: '542', trend: 8 },
//   'exec-kpi-3': { value: '96%', trend: 3 },
//   'exec-kpi-4': { value: '342 ms', trend: -5 },
//   'exec-kpi-5': { value: '2,450 TPS', trend: 10 },
//   'exec-kpi-6': { value: '14', trend: 4 },

//   'exec-line-1': [
//     { name: 'Jan', value: 450 },
//     { name: 'Feb', value: 420 },
//     { name: 'Mar', value: 390 },
//     { name: 'Apr', value: 342 },
//     { name: 'May', value: 360 },
//     { name: 'Jun', value: 310 },
//   ],

//   'autoscript-kpi-1': { value: '320', trend: 15 },
//   'autoscript-kpi-2': { value: '298', trend: 12 },
//   'autoscript-kpi-3': { value: '94%', trend: 5 },
//   'autoscript-kpi-4': { value: '18 sec', trend: -3 },

//   'autonfr-kpi-1': { value: '210', trend: 9 },
//   'autonfr-kpi-2': { value: '97%', trend: 4 },

//   'autoanalysis-bar': [
//     { build: 'Build 1', compliance: 92 },
//     { build: 'Build 2', compliance: 88 },
//     { build: 'Build 3', compliance: 95 },
//     { build: 'Build 4', compliance: 90 },
//   ],

//   'roi-kpi-1': { value: '1,250 hrs', trend: 18 },
//   'roi-kpi-2': { value: '$180K', trend: 22 },
//   'roi-kpi-3': { value: '320%', trend: 25 },
// };


import { WidgetConfig } from '../types/widget';

/* -------------------------------------------------------------------------- */
/*                         Default Configurations                             */
/* -------------------------------------------------------------------------- */

const defaultDataSource = {
  url: '/mock-api',
  method: 'GET' as const,
};

const defaultVisuals = {
  showLegend: true,
  refreshInterval: 0,
};

/* -------------------------------------------------------------------------- */
/*                            Widget Configurations                           */
/* -------------------------------------------------------------------------- */

export const mockWidgets: WidgetConfig[] = [
  /* ====================== 📊 Executive Overview ====================== */
  {
    id: 'exec-kpi-1',
    type: 'KPI',
    title: 'Total Applications Onboarded',
    dataSource: defaultDataSource,
    layout: { x: 0, y: 0, w: 2, h: 2 },
    visuals: { ...defaultVisuals, color: '#1976d2' },
  },
  {
    id: 'exec-kpi-2',
    type: 'KPI',
    title: 'Total Performance Tests Executed',
    dataSource: defaultDataSource,
    layout: { x: 2, y: 0, w: 2, h: 2 },
    visuals: { ...defaultVisuals, color: '#2e7d32' },
  },
  {
    id: 'exec-kpi-3',
    type: 'KPI',
    title: 'Success Rate',
    dataSource: defaultDataSource,
    layout: { x: 4, y: 0, w: 2, h: 2 },
    visuals: { ...defaultVisuals, color: '#ed6c02' },
  },
  {
    id: 'exec-kpi-4',
    type: 'KPI',
    title: 'Average Response Time',
    dataSource: defaultDataSource,
    layout: { x: 6, y: 0, w: 2, h: 2 },
    visuals: { ...defaultVisuals, color: '#9c27b0' },
  },
  {
    id: 'exec-kpi-5',
    type: 'KPI',
    title: 'Peak Throughput',
    dataSource: defaultDataSource,
    layout: { x: 8, y: 0, w: 2, h: 2 },
    visuals: { ...defaultVisuals, color: '#0288d1' },
  },
  {
    id: 'exec-kpi-6',
    type: 'KPI',
    title: 'Active Builds',
    dataSource: defaultDataSource,
    layout: { x: 10, y: 0, w: 2, h: 2 },
    visuals: { ...defaultVisuals, color: '#d32f2f' },
  },
  {
    id: 'exec-line-1',
    type: 'CHART_LINE',
    title: 'Performance Trends',
    dataSource: defaultDataSource,
    layout: { x: 0, y: 2, w: 12, h: 3 },
    visuals: defaultVisuals,
  },

  /* ====================== 🚀 Autoscript Insights ====================== */
  {
    id: 'autoscript-kpi-1',
    type: 'KPI',
    title: 'HAR Files Processed',
    dataSource: defaultDataSource,
    layout: { x: 0, y: 0, w: 3, h: 2 },
    visuals: { ...defaultVisuals, color: '#1976d2' },
  },
  {
    id: 'autoscript-kpi-2',
    type: 'KPI',
    title: 'JMX Files Generated',
    dataSource: defaultDataSource,
    layout: { x: 3, y: 0, w: 3, h: 2 },
    visuals: { ...defaultVisuals, color: '#2e7d32' },
  },
  {
    id: 'autoscript-kpi-3',
    type: 'KPI',
    title: 'Script Success Rate',
    dataSource: defaultDataSource,
    layout: { x: 6, y: 0, w: 3, h: 2 },
    visuals: { ...defaultVisuals, color: '#ed6c02' },
  },
  {
    id: 'autoscript-kpi-4',
    type: 'KPI',
    title: 'Avg Script Generation Time',
    dataSource: defaultDataSource,
    layout: { x: 9, y: 0, w: 3, h: 2 },
    visuals: { ...defaultVisuals, color: '#9c27b0' },
  },

  /* ====================== 📄 AutoNFR Insights ====================== */
  {
    id: 'autonfr-kpi-1',
    type: 'KPI',
    title: 'NFR Documents Generated',
    dataSource: defaultDataSource,
    layout: { x: 0, y: 0, w: 3, h: 2 },
    visuals: { ...defaultVisuals, color: '#0288d1' },
  },
  {
    id: 'autonfr-kpi-2',
    type: 'KPI',
    title: 'Compliance Coverage',
    dataSource: defaultDataSource,
    layout: { x: 3, y: 0, w: 3, h: 2 },
    visuals: { ...defaultVisuals, color: '#ff9800' },
  },

  /* ====================== 🔗 AutoAnalysis Dashboard ====================== */
  {
    id: 'autoanalysis-bar',
    type: 'CHART_BAR',
    title: 'Build Success Rate',
    dataSource: defaultDataSource,
    layout: { x: 0, y: 0, w: 6, h: 3 },
    visuals: defaultVisuals,
  },

  /* ====================== 📈 ROI & Productivity Dashboard ====================== */
  {
    id: 'roi-kpi-1',
    type: 'ROI',
    title: 'Total Time Saved',
    dataSource: defaultDataSource,
    layout: { x: 0, y: 0, w: 3, h: 2 },
    visuals: { ...defaultVisuals, color: '#4caf50' },
  },
  {
    id: 'roi-kpi-2',
    type: 'ROI',
    title: 'Cost Savings',
    dataSource: defaultDataSource,
    layout: { x: 3, y: 0, w: 3, h: 2 },
    visuals: { ...defaultVisuals, color: '#00acc1' },
  },
  {
    id: 'roi-kpi-3',
    type: 'ROI',
    title: 'Return on Investment',
    dataSource: defaultDataSource,
    layout: { x: 6, y: 0, w: 3, h: 2 },
    visuals: { ...defaultVisuals, color: '#8e24aa' },
  },
];

/* -------------------------------------------------------------------------- */
/*                                Widget Data                                 */
/* -------------------------------------------------------------------------- */

export const mockWidgetData: Record<string, any> = {
  /* ====================== Executive Overview ====================== */
  'exec-kpi-1': { value: '128', trend: 12 },
  'exec-kpi-2': { value: '542', trend: 8 },
  'exec-kpi-3': { value: '96%', trend: 3 },
  'exec-kpi-4': { value: '342 ms', trend: -5 },
  'exec-kpi-5': { value: '2,450 TPS', trend: 10 },
  'exec-kpi-6': { value: '14', trend: 4 },

  'exec-line-1': [
    { name: 'Jan', value: 450 },
    { name: 'Feb', value: 420 },
    { name: 'Mar', value: 390 },
    { name: 'Apr', value: 342 },
    { name: 'May', value: 360 },
    { name: 'Jun', value: 310 },
  ],

  /* ====================== Autoscript Insights ====================== */
  'autoscript-kpi-1': { value: '320', trend: 15 },
  'autoscript-kpi-2': { value: '298', trend: 12 },
  'autoscript-kpi-3': { value: '94%', trend: 5 },
  'autoscript-kpi-4': { value: '18 sec', trend: -3 },

  /* ====================== AutoNFR Insights ====================== */
  'autonfr-kpi-1': { value: '210', trend: 9 },
  'autonfr-kpi-2': { value: '97%', trend: 4 },

  /* ====================== AutoAnalysis Dashboard ====================== */
  'autoanalysis-bar': [
    { build: 'Build 1', compliance: 92 },
    { build: 'Build 2', compliance: 88 },
    { build: 'Build 3', compliance: 95 },
    { build: 'Build 4', compliance: 90 },
  ],

  /* ====================== ROI & Productivity Dashboard ====================== */
  'roi-kpi-1': { value: '1,250 hrs', trend: 18 },
  'roi-kpi-2': { value: '$180K', trend: 22 },
  'roi-kpi-3': { value: '320%', trend: 25 },
};